package com.legs.appsforaa;

class User {


    public User(boolean b) {
    }


    boolean activated;

}
